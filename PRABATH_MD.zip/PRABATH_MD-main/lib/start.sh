while true
do
echo "Starting Secktor-Md..."
node lib/client.js
done
